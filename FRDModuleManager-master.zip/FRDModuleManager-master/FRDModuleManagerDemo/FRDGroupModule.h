//
//  FRDGroupModule.h
//  FRDModuleManager
//
//  Created by GUO Lin on 9/29/16.
//  Copyright © 2016 Douban Inc. All rights reserved.
//

#import <FRDModuleManager/FRDModuleManager.h>

@interface FRDGroupModule : NSObject<FRDModule>

@end
