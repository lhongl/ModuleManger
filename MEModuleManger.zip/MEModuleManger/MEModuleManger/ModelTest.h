//
//  ModelTest.h
//  MEModuleManger
//
//  Created by hongliang li on 2017/12/22.
//  Copyright © 2017年 hongliang licom.zhangshangjiankang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ModuleManager.h"
@interface ModelTest : NSObject <Module>

@end
