//
//  AppDelegate.h
//  MEModuleManger
//
//  Created by hongliang li on 2017/12/22.
//  Copyright © 2017年 hongliang licom.zhangshangjiankang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ModuleAppDelegate.h"
@interface AppDelegate : ModuleAppDelegate <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

