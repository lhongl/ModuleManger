//
//  ModuleManager.m
//  MEModuleManger
//
//  Created by hongliang li on 2017/12/22.
//  Copyright © 2017年 hongliang licom.zhangshangjiankang. All rights reserved.
//

#import "ModuleManager.h"
@interface ModuleManager ()

@property (nonatomic, strong) NSMutableArray *modules;

@end

@implementation ModuleManager

+ (instancetype)sharedInstance
{
    static ModuleManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[[self class] alloc] init];
        instance.modules = [NSMutableArray array];
    });
    return instance;
}



+ (NSArray *)allModules
{
    return [ModuleManager sharedInstance].modules;
}

+ (void)registerModule:(Class)moduleClass {
    __block id module = nil;
    [[ModuleManager sharedInstance].modules enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isKindOfClass:[moduleClass class]]) {
            module = obj;
            *stop = YES;
        }
    }];
    if (!module) {
         id module = [[moduleClass alloc] init];
        [[ModuleManager sharedInstance].modules addObject:module];
    }
}

@end
