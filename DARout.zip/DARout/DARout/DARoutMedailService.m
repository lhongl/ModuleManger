//
//  DARoutMedailService.m
//  DARout
//
//  Created by hongliang li on 2018/1/18.
//  Copyright © 2018年 hongliang li. All rights reserved.
//

#import "DARoutMedailService.h"
@interface DARoutMedailService ()
@property (nonatomic, strong)NSMutableDictionary *serviceDiction;
@end
@implementation DARoutMedailService

+ (instancetype)shareMedailService{
    static DARoutMedailService *_instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[DARoutMedailService alloc] init];
        _instance.serviceDiction = [NSMutableDictionary dictionary];
    });
    return _instance;
}

+ (void)registerService:(Class)cls forProtocol:(Protocol *)protocol{
    NSAssert(cls && protocol, @"[DA_DEBUG] class and protocol can not nil");
    NSAssert2([cls conformsToProtocol:protocol], @"[DA_DEBUG] class %@ not conform to %@", NSStringFromClass(cls), NSStringFromProtocol(protocol));
    [[DARoutMedailService shareMedailService].serviceDiction setObject:cls forKey:NSStringFromProtocol(protocol)];
}

+ (Class)serviceClassForProtocol:(Protocol *)protocol{
    NSAssert(protocol, @"[DA_DEBUG] Can not find handler for a nil protocol");
    
    Class handler = [[DARoutMedailService shareMedailService].serviceDiction objectForKey:NSStringFromProtocol(protocol)];
    return handler;
}

@end
