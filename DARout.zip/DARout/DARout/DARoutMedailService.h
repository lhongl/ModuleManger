//
//  DARoutMedailService.h
//  DARout
//
//  Created by hongliang li on 2018/1/18.
//  Copyright © 2018年 hongliang li. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DARoutMedailService : NSObject

/**
 协议的注册

 @param cls 类
 @param protocol 协议名
 */
+ (void)registerService:(Class)cls forProtocol:(Protocol *)protocol;


/**
 通过协议获取类名

 @param protocol 协议名
 @return 类
 */
+ (Class)serviceClassForProtocol:(Protocol *)protocol;
@end
