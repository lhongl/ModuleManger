//
//  subViewController.m
//  DARout
//
//  Created by hongliang li on 2018/1/18.
//  Copyright © 2018年 hongliang li. All rights reserved.
//

#import "subViewController.h"
#import "DARoutMedail.h"
@interface subViewController ()

@end

@implementation subViewController
+ (void)load{
    [DARoutMedail registerRouter:@"da//subviewcontroller" forViewController:self];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(100, 100,100 , 100);
    button.backgroundColor = [UIColor cyanColor];
    [button addTarget:self action:@selector(handle:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    // Do any additional setup after loading the view.
}

- (void)handle:(UIButton *)sender{
    [DARoutMedail gobackToViewControllerwithURL:@"da//testyviewcontroller" animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
