//
//  ViewController.m
//  DARout
//
//  Created by hongliang li on 2018/1/11.
//  Copyright © 2018年 hongliang li. All rights reserved.
//

#import "ViewController.h"
#import "DARoutMedail.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)leftItem:(id)sender {
    [DARoutMedail openURL:@"da//testxviewcontroller"];
}
- (IBAction)rightItem:(id)sender {
    NSDictionary *xx = @{@"name":@"liyan",@"age":@"23"};
    [DARoutMedail openURL:@"da//testyviewcontroller" withUserInfo:@{@"access":xx}];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
