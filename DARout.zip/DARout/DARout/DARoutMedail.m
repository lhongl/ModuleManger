//
//  DARoutMedail.m
//  DARout
//
//  Created by hongliang li on 2018/1/11.
//  Copyright © 2018年 hongliang li. All rights reserved.
//

#import "DARoutMedail.h"
#import "MGJRouter.h"
@interface DARoutMedail ()
@property (nonatomic, weak) id <DARoutMedailPeotocol >delegate;
@end

@implementation DARoutMedail

+ (instancetype)shareRoutMedail{
    static DARoutMedail *_instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[DARoutMedail alloc] init];
    });
    return _instance;
}

+ (void)setDARoutMedailDelegate:(id <DARoutMedailPeotocol>)delegate{
    [DARoutMedail shareRoutMedail].delegate = delegate;
}

//注册
+ (void)registerRouter:(NSString *)router forViewController:(Class)cls{
    NSAssert(router, @"[DA_DEBUG] router不能为空");
    NSAssert([cls isSubclassOfClass:[UIViewController class]], @"[DA_DEBUG] cls必须是UIViewController子类");
    [MGJRouter registerURLPattern:router toObjectHandler:^id(NSDictionary *routerParameters) {
        id objcx = [cls new];
        NSDictionary *userInfo = routerParameters[MGJRouterParameterUserInfo];
        [userInfo enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
            [objcx setValue:obj forKey:key]; //关键点:给objcx赋值
        }];

        return objcx;
    }];
}


+ (void)openURL:(NSString *)url{
    [self openURL:url userInfo:nil];
}

+ (void)openURL:(NSString *)url  withUserInfo:(NSDictionary<NSString *,id> *)userInfo{
    [self openURL:url userInfo:userInfo];
}

+ (void)openURL:(NSString *)url userInfo:(NSDictionary<NSString *,id> *)userInfo{
    if (url == nil) {
        [self openURLFailed:url];
    }
    UIViewController *openview =  [MGJRouter objectForURL:url withUserInfo:userInfo];
    if (openview) {
        [self openViewController:openview];
    }else{
        [self openURLFailed:url];
    }
}

+ (void)openURLFailed:(NSString *)url {
    if ([[DARoutMedail shareRoutMedail].delegate respondsToSelector:@selector(didOpenURLFailed:)]) {
        [[DARoutMedail shareRoutMedail].delegate didOpenURLFailed:url];
    }
}

+ (UIViewController *)viewControllerForURL:(NSString *)url userInfo:(NSDictionary *)userInfo{
    if (userInfo) {
        return [MGJRouter objectForURL:url withUserInfo:userInfo];
    }else{
        return [MGJRouter objectForURL:url withUserInfo:nil];
    }
}

//获取到rootViewController并通过rootViewController进行跳转
+ (void)openViewController:(UIViewController *)viewController {
    if ([self currentViewController].navigationController) {
        [[self currentViewController].navigationController pushViewController:viewController animated:YES];
    } else {
        [[self currentViewController] presentViewController:viewController animated:YES completion:NULL];
    }
}

+ (UIViewController *)currentViewController {
    UIViewController *rootViewController = [self rootViewController];
    
    if ([rootViewController isKindOfClass:[UINavigationController class]]) {
        return [(UINavigationController *)rootViewController visibleViewController];
    } else if ([rootViewController isKindOfClass:[UITabBarController class]]) {
        UITabBarController *tabBarController = (UITabBarController *)rootViewController;
        UIViewController *selectedVC = [tabBarController selectedViewController];
        
        if ([selectedVC isKindOfClass:[UINavigationController class]]) {
            return [(UINavigationController *)selectedVC visibleViewController];
        } else {
            return [self topViewControllerwithtopView:selectedVC];
        }
    } else {
        return [self topViewControllerwithtopView:rootViewController];
    }
}

+ (UIViewController *)topViewControllerwithtopView:(UIViewController *)ViewController {
    UIViewController *topViewController = ViewController;
    while (topViewController.presentedViewController) {
        topViewController = topViewController.presentedViewController;
    }
    return topViewController;
}

+ (UIViewController *)rootViewController {
    return [[[[UIApplication sharedApplication] delegate] window] rootViewController];
}

+ (void)goback:(BOOL)animated {
    if ([self currentViewController].navigationController) {
        if ([self currentViewController] != [self currentViewController].navigationController.viewControllers.firstObject) {
            [[self currentViewController].navigationController popViewControllerAnimated:animated];
        } else if ([self currentViewController].navigationController.presentingViewController) {
            [[self currentViewController].navigationController dismissViewControllerAnimated:animated completion:NULL];
        }
    } else if ([self currentViewController].presentingViewController) {
        [[self currentViewController] dismissViewControllerAnimated:animated completion:NULL];
    }
}

+ (void)gobackToRoot:(BOOL)animated {
    if ([self currentViewController].navigationController) {
        if ([self currentViewController] != [self currentViewController].navigationController.viewControllers.firstObject) {
            [[self currentViewController].navigationController popToRootViewControllerAnimated:animated];
        } else if ([self currentViewController].navigationController.presentingViewController) {
            [[self currentViewController].navigationController dismissViewControllerAnimated:animated completion:^{
                if ([self currentViewController].navigationController) {
                    [[self currentViewController].navigationController popToRootViewControllerAnimated:NO];
                }
            }];
        }
        
    } else if ([self currentViewController].presentingViewController) {
        [[self currentViewController] dismissViewControllerAnimated:animated completion:^{
            if ([self currentViewController].navigationController) {
                [[self currentViewController].navigationController popToRootViewControllerAnimated:NO];
            }
        }];
    }
}

+ (void)gobackToViewControllerwithURL:(NSString *)url animated:(BOOL)animated{
     UIViewController *viewController = [self viewControllerForURL:url userInfo:nil];
    if ([self currentViewController].navigationController) {
        for (UIViewController *controller in [self currentViewController].navigationController.viewControllers) {
            if ([controller isKindOfClass:[viewController class]]) {
                [[self currentViewController].navigationController popToViewController:controller animated:YES];
            }
        }
    }else if ([self currentViewController].presentingViewController) {
        [[self currentViewController] dismissViewControllerAnimated:animated completion:^{
            if ([self currentViewController].navigationController) {
                for (UIViewController *controller in [self currentViewController].navigationController.viewControllers) {
                    if ([controller isKindOfClass:[viewController class]]) {
                        [[self currentViewController].navigationController popToViewController:controller animated:NO];
                    }
                }
            }
        }];
    }
}
@end
