//
//  DARoutMedail.h
//  DARout
//
//  Created by hongliang li on 2018/1/11.
//  Copyright © 2018年 hongliang li. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DARoutMedailPeotocol.h"
#import <UIKit/UIKit.h>
@interface DARoutMedail : NSObject
+ (instancetype)shareRoutMedail;

//设置代理
+ (void)setDARoutMedailDelegate:(id <DARoutMedailPeotocol>)delegate;

/**
 注册

 @param router url
 @param cls 类
 */
+ (void)registerRouter:(NSString *)router forViewController:(Class)cls;

/**
 url跳转

 @param url url
 */
+ (void)openURL:(NSString *)url;

/**
 url跳转

 @param url url
 @param userInfo 参数
 */
+ (void)openURL:(NSString *)url  withUserInfo:(NSDictionary<NSString *,id> *)userInfo;


/**
 通过url创建UIViewController

 @param url url
 @param userInfo 参数
 @return UIViewController
 */
+ (UIViewController *)viewControllerForURL:(NSString *)url userInfo:(NSDictionary *)userInfo;


/**
 获取当前UIViewController

 @return UIViewController
 */
+ (UIViewController *)currentViewController;


/**
 获取根视图

 @return UIViewController
 */
+ (UIViewController *)rootViewController;


/**
 返回上一页面

 @param animated 是否需要动画
 */
+ (void)goback:(BOOL)animated;


/**
 返回到指定页面

 @param url 返回页面url
 @param animated 是否需要donghua
 */
+ (void)gobackToViewControllerwithURL:(NSString *)url animated:(BOOL)animated;

/**
 返回根视图
 @param animated 是否需要动画
 */
+ (void)gobackToRoot:(BOOL)animated;
@end
