//
//  DARoutMedailPeotocol.h
//  DARout
//
//  Created by hongliang li on 2018/1/18.
//  Copyright © 2018年 hongliang li. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol DARoutMedailPeotocol <NSObject>

/**
 打开url失败
 @param url url
 */
- (void)didOpenURLFailed:(NSString *)url;

@end
